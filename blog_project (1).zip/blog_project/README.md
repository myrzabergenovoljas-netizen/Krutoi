# Блог на Django

## Запуск
```
python -m venv venv
venv\Scripts\activate          # Windows
source venv/bin/activate       # macOS / Linux
pip install -r requirements.txt
python manage.py makemigrations blog
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```
Сайт: http://127.0.0.1:8000/   Админка: http://127.0.0.1:8000/admin/
