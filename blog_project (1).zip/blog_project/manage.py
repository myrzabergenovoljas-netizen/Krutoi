#!/usr/bin/env python
# manage.py — главная команда управления проектом.
# Через неё запускаются: runserver (сервер), makemigrations/migrate (база),
# createsuperuser (админ) и другие команды Django.
import os
import sys


def main():
    # Указываем Django, где лежат настройки проекта (файл blog_project/settings.py)
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "blog_project.settings")
    from django.core.management import execute_from_command_line
    # Передаём в Django команду, которую мы набрали в терминале
    execute_from_command_line(sys.argv)


# Этот блок выполняется, только если файл запущен напрямую (python manage.py ...)
if __name__ == "__main__":
    main()
