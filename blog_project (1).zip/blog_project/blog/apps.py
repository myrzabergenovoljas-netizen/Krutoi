# apps.py — конфигурация приложения blog (имя и название в админке).
from django.apps import AppConfig


class BlogConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "blog"               # имя папки приложения
    verbose_name = "Блог"       # как приложение называется в админке
