# views.py — логика сайта. View принимает запрос от браузера,
# достаёт данные из базы и отдаёт готовую страницу (через шаблон).
from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse_lazy
from django.views.generic import (
    CreateView,
    DeleteView,
    DetailView,
    ListView,
    UpdateView,
)

from .forms import ArticleForm, CommentForm, SignUpForm
from .models import Article, Category


class ArticleListView(ListView):
    """Список статей. Доступен ВСЕМ (и неавторизованным).
    ListView — готовый класс Django для вывода списка объектов."""

    model = Article
    template_name = "blog/article_list.html"   # какой HTML использовать
    context_object_name = "articles"           # имя списка в шаблоне ({% for article in articles %})
    paginate_by = 5                            # ПАГИНАЦИЯ: по 5 статей на страницу

    def get_queryset(self):
        # Какие именно статьи выбрать из базы.
        # select_related / prefetch_related — оптимизация: меньше запросов к базе.
        qs = (
            Article.objects.select_related("author", "category")
            .prefetch_related("likes")
        )
        # Фильтры из адреса: /?category=1 и /?tag=django
        category = self.request.GET.get("category")
        tag = self.request.GET.get("tag")
        if category:
            qs = qs.filter(category_id=category)
        if tag:
            qs = qs.filter(tags__icontains=tag)   # icontains — поиск без учёта регистра
        return qs

    def get_context_data(self, **kwargs):
        # Добавляем в шаблон дополнительные переменные
        ctx = super().get_context_data(**kwargs)
        ctx["categories"] = Category.objects.all()                      # для выпадающего списка
        ctx["current_category"] = self.request.GET.get("category", "")  # запоминаем выбор
        ctx["current_tag"] = self.request.GET.get("tag", "")
        # Собираем параметры фильтра, чтобы они не пропадали при переходе на другую страницу
        params = self.request.GET.copy()
        params.pop("page", None)
        ctx["query_string"] = params.urlencode()
        return ctx


class ArticleDetailView(DetailView):
    """Страница одной статьи + комментарии под ней. Доступна всем."""

    model = Article
    template_name = "blog/article_detail.html"
    context_object_name = "article"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        # Комментарии статьи (порядок — хронологический, задан в модели)
        ctx["comments"] = self.object.comments.select_related("author")
        ctx["comment_form"] = CommentForm()   # пустая форма комментария
        user = self.request.user
        # Лайкнул ли текущий пользователь эту статью (для текста на кнопке)
        ctx["user_liked"] = (
            user.is_authenticated and self.object.likes.filter(pk=user.pk).exists()
        )
        return ctx

    def post(self, request, *args, **kwargs):
        """Обработка отправки комментария (метод POST)."""
        # Комментировать могут только авторизованные — иначе отправляем на вход
        if not request.user.is_authenticated:
            return redirect(f"{reverse_lazy('login')}?next={request.path}")
        self.object = self.get_object()          # получаем статью
        form = CommentForm(request.POST)         # заполняем форму данными из запроса
        if form.is_valid():                      # проверка данных
            comment = form.save(commit=False)    # создаём комментарий, но пока не сохраняем
            comment.article = self.object        # привязываем к статье
            comment.author = request.user        # автор = текущий пользователь
            comment.save()                       # теперь сохраняем в базу
            messages.success(request, "Комментарий добавлен.")
            return redirect(self.object.get_absolute_url())
        # Если форма с ошибками — показываем страницу снова с сообщениями об ошибках
        ctx = self.get_context_data(object=self.object)
        ctx["comment_form"] = form
        return self.render_to_response(ctx)


class ArticleCreateView(LoginRequiredMixin, CreateView):
    """Создание статьи.
    LoginRequiredMixin — пускает только авторизованных, остальных шлёт на страницу входа."""

    model = Article
    form_class = ArticleForm
    template_name = "blog/article_form.html"

    def form_valid(self, form):
        # Вызывается, когда форма заполнена правильно.
        # Автора ставим здесь, на сервере — пользователь не может его подменить.
        form.instance.author = self.request.user
        messages.success(self.request, "Статья опубликована.")
        return super().form_valid(form)   # сохранение и переход на страницу статьи


class AuthorRequiredMixin(UserPassesTestMixin):
    """Проверка прав: действие разрешено только автору статьи.
    Если test_func вернул False — пользователь получит ошибку 403 (доступ запрещён)."""

    def test_func(self):
        return self.get_object().author == self.request.user


class ArticleUpdateView(LoginRequiredMixin, AuthorRequiredMixin, UpdateView):
    """Редактирование статьи: нужен вход + быть автором."""

    model = Article
    form_class = ArticleForm
    template_name = "blog/article_form.html"   # тот же шаблон, что и для создания

    def form_valid(self, form):
        messages.success(self.request, "Статья обновлена.")
        return super().form_valid(form)


class ArticleDeleteView(LoginRequiredMixin, AuthorRequiredMixin, DeleteView):
    """Удаление статьи: нужен вход + быть автором. Сначала показывается страница подтверждения."""

    model = Article
    template_name = "blog/article_confirm_delete.html"
    success_url = reverse_lazy("article_list")   # куда идти после удаления

    def form_valid(self, form):
        messages.success(self.request, "Статья удалена.")
        return super().form_valid(form)


@login_required   # декоратор: функция доступна только авторизованным
def toggle_like(request, pk):
    """Поставить лайк, а если уже стоит — убрать."""
    if request.method != "POST":              # лайк меняет данные, поэтому только POST
        return redirect("article_detail", pk=pk)
    article = get_object_or_404(Article, pk=pk)   # найти статью или показать ошибку 404
    if article.likes.filter(pk=request.user.pk).exists():
        article.likes.remove(request.user)    # лайк уже был — убираем
    else:
        article.likes.add(request.user)       # лайка не было — добавляем
    return redirect(request.POST.get("next") or article.get_absolute_url())


class SignUpView(CreateView):
    """Регистрация нового пользователя."""

    form_class = SignUpForm
    template_name = "registration/signup.html"
    success_url = reverse_lazy("article_list")

    def form_valid(self, form):
        response = super().form_valid(form)   # сохраняем пользователя
        login(self.request, self.object)      # сразу входим под ним
        messages.success(self.request, "Добро пожаловать! Регистрация прошла успешно.")
        return response
