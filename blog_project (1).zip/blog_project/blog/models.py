# models.py — описание данных. Каждый класс = таблица в базе данных,
# каждое поле класса = столбец таблицы.
from django.conf import settings
from django.db import models
from django.urls import reverse
from django.utils import timezone


class Category(models.Model):
    """Категория статьи (необязательное задание: категории)."""

    # CharField — короткая строка; unique=True — названия не повторяются
    name = models.CharField("Название", max_length=100, unique=True)

    class Meta:
        # Meta — дополнительные настройки модели
        verbose_name = "Категория"             # название в админке (ед. число)
        verbose_name_plural = "Категории"      # название в админке (мн. число)
        ordering = ["name"]                    # сортировать по алфавиту

    def __str__(self):
        # Как объект выглядит в админке и при выводе: просто его название
        return self.name


class Article(models.Model):
    """Статья блога — главная модель проекта."""

    # Заголовок статьи (короткая строка до 200 символов)
    title = models.CharField("Заголовок", max_length=200)

    # Текст статьи (длинный текст без ограничения)
    content = models.TextField("Содержание")

    # Дата публикации. default=timezone.now — по умолчанию подставляется текущее время,
    # но пользователь может изменить его в форме (как требует задание).
    created_at = models.DateTimeField("Дата публикации", default=timezone.now)

    # Автор статьи. ForeignKey = связь «один ко многим»:
    # у одного пользователя может быть много статей, а у статьи только один автор.
    author = models.ForeignKey(
        settings.AUTH_USER_MODEL,       # встроенная модель User
        on_delete=models.CASCADE,       # если удалить пользователя — удалятся и его статьи
        related_name="articles",        # user.articles.all() — все статьи пользователя
        verbose_name="Автор",
    )

    # Категория (дополнительное задание). null/blank=True — поле необязательное.
    category = models.ForeignKey(
        Category,
        on_delete=models.SET_NULL,      # при удалении категории статья остаётся, поле станет пустым
        null=True,                      # в базе может быть пустое значение
        blank=True,                     # в форме можно не заполнять
        related_name="articles",
        verbose_name="Категория",
    )

    # Теги одной строкой через запятую (дополнительное задание)
    tags = models.CharField(
        "Теги (через запятую)", max_length=200, blank=True
    )

    # Картинка к статье (дополнительное задание). Требует библиотеку Pillow.
    # upload_to — подпапка внутри media/, куда сохраняется файл.
    image = models.ImageField(
        "Изображение", upload_to="articles/", blank=True, null=True
    )

    # Лайки. ManyToManyField = «многие ко многим»:
    # один пользователь лайкает много статей, у статьи много лайкнувших.
    likes = models.ManyToManyField(
        settings.AUTH_USER_MODEL,
        related_name="liked_articles",
        blank=True,
        verbose_name="Лайки",
    )

    class Meta:
        verbose_name = "Статья"
        verbose_name_plural = "Статьи"
        ordering = ["-created_at"]      # сначала новые статьи (минус = по убыванию)

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        # Адрес страницы статьи. Используется в шаблонах и после сохранения формы.
        return reverse("article_detail", kwargs={"pk": self.pk})

    def tag_list(self):
        # Превращает строку "django, python" в список ["django", "python"]
        return [t.strip() for t in self.tags.split(",") if t.strip()]

    def total_likes(self):
        # Количество лайков статьи
        return self.likes.count()


class Comment(models.Model):
    """Комментарий к статье (дополнительное задание)."""

    # К какой статье относится комментарий.
    # related_name="comments" позволяет писать article.comments.all()
    article = models.ForeignKey(
        Article,
        on_delete=models.CASCADE,       # удалили статью — удалились её комментарии
        related_name="comments",
        verbose_name="Статья",
    )

    # Автор комментария
    author = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="comments",
        verbose_name="Автор",
    )

    # Текст комментария
    text = models.TextField("Комментарий")

    # auto_now_add=True — дата ставится автоматически при создании
    created_at = models.DateTimeField("Дата", auto_now_add=True)

    class Meta:
        verbose_name = "Комментарий"
        verbose_name_plural = "Комментарии"
        ordering = ["created_at"]       # старые сверху = хронологический порядок (по заданию)

    def __str__(self):
        return f"{self.author} → {self.article}"
