# admin.py — регистрация моделей в панели администратора (/admin/).
# Без регистрации модель в админке не появится.
from django.contrib import admin

from .models import Article, Category, Comment


# @admin.register(Модель) — декоратор, который регистрирует модель в админке.
@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name",)        # какие столбцы показывать в списке
    search_fields = ("name",)       # по каким полям работает строка поиска


@admin.register(Article)
class ArticleAdmin(admin.ModelAdmin):
    list_display = ("title", "author", "category", "created_at")   # столбцы таблицы
    list_filter = ("category", "created_at", "author")             # фильтры справа
    search_fields = ("title", "content", "tags")                   # поиск по тексту
    date_hierarchy = "created_at"                                  # навигация по датам сверху


@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ("author", "article", "created_at")
    list_filter = ("created_at",)
    search_fields = ("text",)
