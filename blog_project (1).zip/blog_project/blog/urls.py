# urls.py приложения blog — адреса страниц блога.
# path("адрес", view, name="имя"). По name адрес можно вызывать в шаблонах: {% url 'имя' %}
from django.urls import path

from . import views

urlpatterns = [
    # Главная: список статей
    path("", views.ArticleListView.as_view(), name="article_list"),
    # Создание статьи (только для вошедших)
    path("article/new/", views.ArticleCreateView.as_view(), name="article_create"),
    # <int:pk> — число в адресе (номер статьи), передаётся во view как pk
    path("article/<int:pk>/", views.ArticleDetailView.as_view(), name="article_detail"),
    # Редактирование и удаление (только автор)
    path("article/<int:pk>/edit/", views.ArticleUpdateView.as_view(), name="article_update"),
    path("article/<int:pk>/delete/", views.ArticleDeleteView.as_view(), name="article_delete"),
    # Лайк
    path("article/<int:pk>/like/", views.toggle_like, name="article_like"),
    # Регистрация
    path("signup/", views.SignUpView.as_view(), name="signup"),
]
