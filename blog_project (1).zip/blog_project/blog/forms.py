# forms.py — формы. Форма отвечает за вывод полей на странице,
# проверку введённых данных и сохранение.
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from .models import Article, Comment

# Формат даты для поля <input type="datetime-local"> в браузере
DT_FORMAT = "%Y-%m-%dT%H:%M"


class ArticleForm(forms.ModelForm):
    """Форма создания и редактирования статьи.
    ModelForm сама строит поля по модели Article — не нужно описывать их вручную."""

    class Meta:
        model = Article   # из какой модели делаем форму
        # Какие поля показывать. Автора здесь НЕТ специально:
        # он ставится на сервере (во view), чтобы нельзя было подделать.
        fields = ["title", "content", "created_at", "category", "tags", "image"]
        widgets = {
            # Виджет — как поле выглядит в HTML. Здесь: календарь с выбором даты и времени.
            "created_at": forms.DateTimeInput(
                attrs={"type": "datetime-local"}, format=DT_FORMAT
            ),
            # Большое текстовое поле на 10 строк для статьи
            "content": forms.Textarea(attrs={"rows": 10}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Говорим форме, в каких форматах принимать дату от браузера
        self.fields["created_at"].input_formats = [DT_FORMAT, "%Y-%m-%d %H:%M:%S"]


class CommentForm(forms.ModelForm):
    """Форма комментария: единственное поле — текст.
    Статью и автора view подставляет сам."""

    class Meta:
        model = Comment
        fields = ["text"]
        widgets = {
            "text": forms.Textarea(
                attrs={"rows": 3, "placeholder": "Ваш комментарий..."}
            )
        }
        labels = {"text": ""}   # убираем подпись над полем


class SignUpForm(UserCreationForm):
    """Форма регистрации. UserCreationForm — готовая форма Django:
    сама проверяет, что пароли совпадают, он надёжный, и сохраняет его в виде хеша."""

    email = forms.EmailField(required=False, label="Email")   # добавили необязательную почту

    class Meta(UserCreationForm.Meta):
        model = User
        fields = ("username", "email")   # password1 и password2 добавляются автоматически
