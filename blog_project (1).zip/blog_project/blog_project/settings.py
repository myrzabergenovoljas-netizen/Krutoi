# settings.py — настройки всего проекта.
from pathlib import Path

# BASE_DIR — корневая папка проекта (та, где лежит manage.py).
# От неё считаются пути к базе, шаблонам и картинкам.
BASE_DIR = Path(__file__).resolve().parent.parent

# Секретный ключ: нужен для подписи сессий и защиты форм.
# В реальном проекте его прячут и никому не показывают.
SECRET_KEY = "django-insecure-change-me-in-production"

# DEBUG = True показывает подробные ошибки. На боевом сервере ставят False.
DEBUG = True

# Список доменов, на которых разрешена работа сайта (при DEBUG пустой список допустим)
ALLOWED_HOSTS = []

# Подключённые приложения. Всё, что здесь не указано, Django «не видит».
INSTALLED_APPS = [
    "django.contrib.admin",         # панель администратора (/admin/)
    "django.contrib.auth",          # пользователи, пароли, вход и выход
    "django.contrib.contenttypes",  # служебное: нужно для работы прав и админки
    "django.contrib.sessions",      # сессии: так сайт «помнит», что вы вошли
    "django.contrib.messages",      # всплывающие сообщения («Статья удалена»)
    "django.contrib.staticfiles",   # статические файлы (css, js)
    "blog",                         # НАШЕ приложение с блогом
]

# Middleware — «прослойки», через которые проходит каждый запрос.
MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",            # базовая безопасность
    "django.contrib.sessions.middleware.SessionMiddleware",     # включает сессии
    "django.middleware.common.CommonMiddleware",                # общие мелочи (слеши в адресах)
    "django.middleware.csrf.CsrfViewMiddleware",                # защита форм от подделки (CSRF)
    "django.contrib.auth.middleware.AuthenticationMiddleware",  # добавляет request.user
    "django.contrib.messages.middleware.MessageMiddleware",     # включает messages
    "django.middleware.clickjacking.XFrameOptionsMiddleware",   # защита от встраивания сайта в чужой iframe
]

# Главный файл с адресами сайта
ROOT_URLCONF = "blog_project.urls"

# Настройки шаблонов (HTML-страниц)
TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        # DIRS — общая папка шаблонов проекта (base.html, login.html, signup.html)
        "DIRS": [BASE_DIR / "templates"],
        # APP_DIRS — искать шаблоны ещё и внутри приложений (blog/templates/)
        "APP_DIRS": True,
        "OPTIONS": {
            # Context processors добавляют переменные во ВСЕ шаблоны автоматически
            "context_processors": [
                "django.template.context_processors.request",       # переменная request
                "django.contrib.auth.context_processors.auth",      # переменная user
                "django.contrib.messages.context_processors.messages",  # переменная messages
            ],
        },
    },
]

# Точка входа для веб-сервера при деплое
WSGI_APPLICATION = "blog_project.wsgi.application"

# База данных. SQLite — это просто файл db.sqlite3, ничего устанавливать не нужно.
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": BASE_DIR / "db.sqlite3",
    }
}

# Проверки надёжности пароля при регистрации
AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},  # не похож на логин
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},             # минимум 8 символов
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},            # не из списка популярных
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},           # не только цифры
]

LANGUAGE_CODE = "ru"          # язык интерфейса (формы, админка — на русском)
TIME_ZONE = "Asia/Almaty"     # часовой пояс для дат
USE_I18N = True               # включить переводы
USE_TZ = True                 # хранить время с учётом часового пояса

# Статические файлы (css, js)
STATIC_URL = "static/"

# Файлы, которые загружают пользователи (картинки к статьям)
MEDIA_URL = "/media/"                 # адрес в браузере: /media/articles/photo.jpg
MEDIA_ROOT = BASE_DIR / "media"       # папка на диске, куда файлы сохраняются

# Тип автоматического поля id в таблицах
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# Куда отправлять неавторизованных (имя маршрута из urls.py)
LOGIN_URL = "login"
# Куда перенаправлять после успешного входа
LOGIN_REDIRECT_URL = "article_list"
# Куда перенаправлять после выхода
LOGOUT_REDIRECT_URL = "article_list"
