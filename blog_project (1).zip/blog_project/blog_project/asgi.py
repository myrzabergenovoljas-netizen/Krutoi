# asgi.py — то же, что wsgi.py, но для асинхронных серверов (современный вариант).
import os

from django.core.asgi import get_asgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "blog_project.settings")
application = get_asgi_application()
