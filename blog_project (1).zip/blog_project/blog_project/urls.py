# urls.py проекта — главный «справочник адресов» сайта.
# Django берёт адрес из браузера и ищет, какой кусок кода его обработает.
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    # /admin/ — встроенная панель администратора
    path("admin/", admin.site.urls),
    # /accounts/login/ и /accounts/logout/ — готовые адреса входа и выхода от Django
    path("accounts/", include("django.contrib.auth.urls")),
    # Всё остальное ("" = корень сайта) передаём в адреса приложения blog
    path("", include("blog.urls")),
]

# В режиме разработки раздаём загруженные картинки по адресу /media/...
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
